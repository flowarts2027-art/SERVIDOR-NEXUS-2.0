"""Explicit local YouTube download, then upload the saved MP4 in Nexus."""
import argparse
import html
import json
import pathlib
import re
import secrets
import subprocess
import sys
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

MAX_BYTES = 90 * 1024 * 1024
ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")

def youtube_url(value):
    value = str(value).strip()
    if ID_RE.fullmatch(value):
        video_id = value
    else:
        url = urlsplit(value)
        if url.scheme != "https" or url.username or url.password or url.port:
            raise ValueError("Use um link HTTPS público do YouTube.")
        host = (url.hostname or "").lower()
        query = parse_qs(url.query)
        if host == "youtu.be":
            video_id = url.path.strip("/")
        elif host in {"youtube.com", "www.youtube.com", "m.youtube.com"}:
            if url.path == "/watch":
                video_id = query.get("v", [""])[0]
            elif url.path.startswith(("/shorts/", "/embed/", "/live/")):
                video_id = url.path.split("/")[2]
            else:
                raise ValueError("Link de vídeo YouTube inválido.")
        else:
            raise ValueError("Somente vídeos públicos do YouTube.")
    if not ID_RE.fullmatch(video_id):
        raise ValueError("Identificador de vídeo inválido.")
    return "https://www.youtube.com/watch?v=" + video_id

def select_format(info):
    formats = info.get("formats", [])
    audio = [f for f in formats if str(f.get("language", "")).lower().replace("_", "-").split("-")[0] == "pt" and f.get("acodec") not in (None, "none") and f.get("vcodec") == "none"]
    if not audio:
        raise ValueError("audio_pt_unconfirmed: o YouTube não confirmou uma faixa de áudio em português. Escolha outro trailer oficial dublado.")
    videos = [f for f in formats if f.get("vcodec") not in (None, "none") and f.get("acodec") == "none" and 0 < (f.get("height") or 0) <= 720]
    if not videos:
        raise ValueError("Nenhum vídeo até 720p disponível.")
    video = max(videos, key=lambda f: (str(f.get("vcodec", "")).startswith("avc1"), f.get("protocol") == "https", f.get("height") or 0, f.get("tbr") or 0))
    track = max(audio, key=lambda f: (str(f.get("acodec", "")).startswith("mp4a"), f.get("protocol") == "https", f.get("abr") or f.get("tbr") or 0))
    return str(video["format_id"]) + "+" + str(track["format_id"])

def probe(path, ffprobe):
    data = json.loads(subprocess.check_output([str(ffprobe), "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)], timeout=30))
    videos = [s for s in data.get("streams", []) if s.get("codec_type") == "video"]
    audios = [s for s in data.get("streams", []) if s.get("codec_type") == "audio"]
    if not videos or not audios or float(data.get("format", {}).get("duration", 0)) <= 0:
        raise ValueError("Arquivo sem vídeo/áudio válido.")
    return videos[0], audios[0]

class Downloader:
    def __init__(self, output, ffmpeg, node):
        self.output = pathlib.Path(output).resolve()
        self.output.mkdir(parents=True, exist_ok=True)
        self.ffmpeg = pathlib.Path(ffmpeg).resolve()
        self.ffprobe = self.ffmpeg.with_name("ffprobe.exe" if sys.platform == "win32" else "ffprobe")
        self.node = node
        self.lock = threading.Lock()
        self.state = {"status": "idle", "message": "Cole o link e baixe o MP4 para o computador."}
        self.files = {}

    def start(self, url):
        url = youtube_url(url)
        with self.lock:
            if self.state["status"] == "busy":
                raise ValueError("Um download já está em andamento.")
            self.state = {"status": "busy", "message": "Consultando vídeo e áudio em português…", "progress": 0}
        threading.Thread(target=self.download, args=(url,), daemon=True).start()

    def update(self, **kwargs):
        with self.lock:
            self.state.update(kwargs)

    def download(self, url):
        directory = self.output / secrets.token_hex(16)
        try:
            directory.mkdir()
            from yt_dlp import YoutubeDL
            class Quiet:
                def debug(self, msg): pass
                def warning(self, msg): pass
                def error(self, msg): pass
            def progress(data):
                if data.get("status") == "downloading":
                    total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
                    downloaded = data.get("downloaded_bytes") or 0
                    if downloaded > MAX_BYTES:
                        raise ValueError("Vídeo ultrapassa o limite de 90 MB.")
                    percent = min(95, round(downloaded / total * 90)) if total else 0
                    self.update(message="Baixando vídeo para o PC…", progress=percent)
            options = {"noplaylist": True, "quiet": True, "logger": Quiet(), "js_runtimes": {"node": {"path": self.node}}, "socket_timeout": 30, "retries": 3, "fragment_retries": 3, "ffmpeg_location": str(self.ffmpeg.parent), "max_filesize": MAX_BYTES, "outtmpl": str(directory / "source.%(ext)s"), "merge_output_format": "mp4", "progress_hooks": [progress]}
            with YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=False)
            if info.get("is_live") or (info.get("duration") or 0) > 3600:
                raise ValueError("Escolha um vídeo gravado com até uma hora.")
            options["format"] = select_format(info)
            with YoutubeDL(options) as ydl:
                ydl.download([url])
            source = directory / "source.mp4"
            if not source.is_file():
                raise ValueError("O download não produziu MP4 completo.")
            self.update(message="Validando MP4 e preparando compatibilidade…", progress=96)
            video, audio = probe(source, self.ffprobe)
            final = directory / "video.mp4"
            cmd = [str(self.ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source), "-map", "0:v:0", "-map", "0:a:0", "-c:v", "copy" if video.get("codec_name") == "h264" else "libx264"]
            if video.get("codec_name") != "h264":
                cmd += ["-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p"]
            cmd += ["-c:a", "copy" if audio.get("codec_name") == "aac" else "aac", "-metadata:s:a:0", "language=por", "-movflags", "+faststart", str(final)]
            subprocess.run(cmd, check=True, timeout=1800, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            video, audio = probe(final, self.ffprobe)
            if video.get("codec_name") != "h264" or audio.get("codec_name") != "aac" or video.get("height", 0) > 720 or not 0 < final.stat().st_size <= MAX_BYTES:
                raise ValueError("MP4 incompatível ou maior que 90 MB. Escolha um trailer menor.")
            source.unlink()
            file_id = directory.name
            self.files[file_id] = final
            self.update(status="ready", message="MP4 salvo no PC. No Nexus, use Enviar do PC para gerar.", progress=100, file_id=file_id, path=str(final), title=str(info.get("title") or "Vídeo YouTube"), bytes=final.stat().st_size)
        except Exception as exc:
            message = str(exc)
            if "audio_pt_unconfirmed" not in message and not isinstance(exc, ValueError):
                message = "Não foi possível baixar este vídeo público. O YouTube pode ter bloqueado o download; tente outro trailer."
            self.update(status="error", message=message[:400], progress=0)
            # Only remove incomplete files in this freshly created job directory.
            try:
                if directory.is_dir():
                    for path in directory.iterdir():
                        if path.is_file():
                            path.unlink()
            except OSError:
                pass

PAGE = '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Nexus — Baixar no PC</title><style>body{font:17px system-ui;background:#0e1728;color:#e9eef8;max-width:760px;margin:60px auto;padding:20px}input,button{font:inherit;padding:14px;border-radius:9px}input{box-sizing:border-box;width:100%;margin:12px 0}button{background:#96e4c6;color:#102018;cursor:pointer}a{color:#96e4c6}p{line-height:1.6}code{overflow-wrap:anywhere}progress{width:100%}</style><h1>Baixar YouTube no computador</h1><p>Baixe o trailer oficial dublado em português. Depois volte ao painel Nexus e envie o MP4 em <strong>Enviar do PC</strong> para gerar o vídeo.</p><form id="form"><label>Link do YouTube<input id="url" required value="__URL__" maxlength="2048"></label><button id="submit">Baixar MP4 no PC</button></form><p id="message"></p><progress id="progress" max="100" value="0"></progress><p id="file"></p><p id="path"></p><script>const token=__TOKEN__;let localError="";const form=document.getElementById('form');form.onsubmit=async e=>{e.preventDefault();localError="";document.getElementById('submit').disabled=true;try{const r=await fetch('/download',{method:'POST',headers:{'Content-Type':'application/json','X-Nexus-CSRF':token},body:JSON.stringify({url:document.getElementById('url').value})});const data=await r.json();if(!r.ok){localError=data.message||"Falha ao iniciar download.";document.getElementById('message').textContent=localError}else{localError=""}}catch(e){localError="Falha de conexão com o serviço local.";document.getElementById('message').textContent=localError}finally{await poll()}};async function poll(){try{const r=await fetch('/status');if(!r.ok)return;const s=await r.json();if(s.status==="busy")localError="";document.getElementById('message').textContent=localError||s.message;document.getElementById('progress').value=s.progress||0;document.getElementById('submit').disabled=s.status==='busy';const file=document.getElementById('file');file.replaceChildren();if(s.status==='ready'){const a=document.createElement('a');a.href='/files/'+s.file_id;a.textContent='Salvar uma cópia do MP4';a.download='nexus-youtube.mp4';file.append(a);document.getElementById('path').textContent='Arquivo no computador: '+s.path}else{document.getElementById('path').textContent=''}}catch(e){document.getElementById('message').textContent='O serviço local foi encerrado. Abra-o novamente.'}}poll();setInterval(poll,1500);</script></html>'''

def make_handler(downloader):
    sessions = {}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def origin(self): return "http://127.0.0.1:" + str(self.server.server_port)
        def host_valid(self): return self.headers.get("Host") == "127.0.0.1:" + str(self.server.server_port)
        def session(self):
            try:
                cookies = SimpleCookie(self.headers.get("Cookie", ""))
                key = cookies["nexus_local"].value if "nexus_local" in cookies else ""
                entry = sessions.get(key)
                return entry[0] if entry and entry[1] > time.time() else None
            except Exception:
                return None
        def send(self, status, payload, kind="application/json", cookie=None):
            raw = payload.encode("utf-8") if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", kind + "; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
            if cookie: self.send_header("Set-Cookie", cookie)
            self.end_headers()
            self.wfile.write(raw)
        def do_GET(self):
            if not self.host_valid():
                return self.send(403, {"message": "Host inválido."})
            path = urlsplit(self.path)
            if path.path == "/":
                key, token = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
                sessions[key] = (token, time.time() + 12 * 3600)
                for old in list(sessions):
                    if sessions[old][1] <= time.time(): sessions.pop(old)
                url = parse_qs(path.query).get("url", [""])[0][:2048]
                page = PAGE.replace("__URL__", html.escape(url, quote=True)).replace("__TOKEN__", json.dumps(token))
                return self.send(200, page, "text/html", "nexus_local=" + key + "; HttpOnly; SameSite=Strict; Path=/")
            if not self.session(): return self.send(403, {"message": "Abra a página local primeiro."})
            if path.path == "/status":
                with downloader.lock: state = dict(downloader.state)
                return self.send(200, state)
            if path.path.startswith("/files/"):
                file_id = path.path.removeprefix("/files/")
                file = downloader.files.get(file_id) if re.fullmatch(r"[a-f0-9]{32}", file_id) else None
                if not file or not file.is_file(): return self.send(404, {"message": "Arquivo indisponível."})
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Content-Length", str(file.stat().st_size))
                self.send_header("Content-Disposition", 'attachment; filename="nexus-youtube.mp4"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                with file.open("rb") as body:
                    while chunk := body.read(1024 * 1024): self.wfile.write(chunk)
                return
            return self.send(404, {"message": "Página indisponível."})
        def do_POST(self):
            token = self.session()
            if not self.host_valid() or self.headers.get("Origin") != self.origin() or not token or not secrets.compare_digest(self.headers.get("X-Nexus-CSRF", ""), token):
                return self.send(403, {"message": "Abra a página local e tente novamente."})
            if self.path != "/download": return self.send(404, {"message": "Rota indisponível."})
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 4096 or self.headers.get("Content-Type") != "application/json":
                    raise ValueError("Pedido inválido.")
                data = json.loads(self.rfile.read(size))
                downloader.start(data.get("url", ""))
                return self.send(202, {"message": "Download iniciado."})
            except (ValueError, TypeError, AttributeError):
                return self.send(400, {"message": "Link inválido ou download em andamento. Use um vídeo público do YouTube."})
        def do_OPTIONS(self): self.send(403, {"message": "Acesso permitido somente pela página local."})
    return Handler

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--ffmpeg", required=True)
    parser.add_argument("--node", required=True)
    parser.add_argument("--deps")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if args.deps: sys.path.insert(0, str(pathlib.Path(args.deps).resolve()))
    downloader = Downloader(args.output, args.ffmpeg, args.node)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(downloader))
    print("Nexus local pronto: http://127.0.0.1:" + str(args.port), flush=True)
    server.serve_forever()
